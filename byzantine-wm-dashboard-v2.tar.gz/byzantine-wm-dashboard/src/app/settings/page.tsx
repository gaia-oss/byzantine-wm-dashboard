'use client';

import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useI18n } from '@/i18n/context';
import { mockProfile } from '@/lib/mock-data';
import type { WealthManagerProfile } from '@/types';

export default function SettingsPage() {
  const { t, locale, setLocale } = useI18n();
  const [profile, setProfile] = useState<WealthManagerProfile>(mockProfile);
  const [saveMessage, setSaveMessage] = useState('');
  const [payoutMethod, setPayoutMethod] = useState<'bank_transfer' | 'byzantine_prime'>(mockProfile.payoutMethod);
  const [bankDetails, setBankDetails] = useState(mockProfile.bankDetails || { iban: '', bic: '', bankName: '' });

  // Format date
  const formatPartnerSince = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    }).format(date);
  };

  // Handle profile changes
  const handleProfileChange = (field: keyof WealthManagerProfile, value: any) => {
    setProfile(prev => ({ ...prev, [field]: value }));
  };

  // Handle bank details changes
  const handleBankDetailsChange = (field: keyof typeof bankDetails, value: string) => {
    setBankDetails(prev => ({ ...prev, [field]: value }));
  };

  // Save profile
  const handleSaveProfile = async () => {
    setSaveMessage('');
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 500));
    setSaveMessage(t.settings.saved);
    setTimeout(() => setSaveMessage(''), 3000);
  };

  // Toggle notifications
  const [notifications, setNotifications] = useState({
    newDeposits: true,
    withdrawals: true,
    payoutNotifications: true,
    monthlySummary: true,
    weeklyPipeline: true,
  });

  const handleNotificationToggle = (key: keyof typeof notifications) => {
    setNotifications(prev => ({ ...prev, [key]: !prev[key] }));
  };

  return (
    <div className="min-h-screen bg-surface-secondary p-8">
      <div className="max-w-3xl mx-auto space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-text-primary mb-2">{t.settings.title}</h1>
          <p className="text-text-secondary">{t.settings.subtitle}</p>
        </div>

        {/* A. Profile Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-card p-8 space-y-6"
        >
          <div>
            <h2 className="text-xl font-semibold text-text-primary mb-2">{t.settings.profile}</h2>
            <p className="text-sm text-text-secondary">
              {t.settings.partnerSince}: {formatPartnerSince(mockProfile.partnerSince)}
            </p>
          </div>

          <div className="grid grid-cols-2 gap-6">
            {/* Full Name */}
            <div>
              <label className="block text-sm font-medium text-text-primary mb-2">{t.settings.name}</label>
              <input
                type="text"
                value={profile.name}
                onChange={(e) => handleProfileChange('name', e.target.value)}
                className="w-full px-4 py-3 bg-surface border border-border rounded-lg text-text-primary focus:outline-none focus:ring-2 focus:ring-byzantine focus:border-transparent"
              />
            </div>

            {/* Company */}
            <div>
              <label className="block text-sm font-medium text-text-primary mb-2">{t.settings.company}</label>
              <input
                type="text"
                value={profile.company}
                onChange={(e) => handleProfileChange('company', e.target.value)}
                className="w-full px-4 py-3 bg-surface border border-border rounded-lg text-text-primary focus:outline-none focus:ring-2 focus:ring-byzantine focus:border-transparent"
              />
            </div>

            {/* Email */}
            <div>
              <label className="block text-sm font-medium text-text-primary mb-2">{t.settings.email}</label>
              <input
                type="email"
                value={profile.email}
                onChange={(e) => handleProfileChange('email', e.target.value)}
                className="w-full px-4 py-3 bg-surface border border-border rounded-lg text-text-primary focus:outline-none focus:ring-2 focus:ring-byzantine focus:border-transparent"
              />
            </div>

            {/* Phone */}
            <div>
              <label className="block text-sm font-medium text-text-primary mb-2">{t.settings.phone}</label>
              <input
                type="tel"
                value={profile.phone}
                onChange={(e) => handleProfileChange('phone', e.target.value)}
                className="w-full px-4 py-3 bg-surface border border-border rounded-lg text-text-primary focus:outline-none focus:ring-2 focus:ring-byzantine focus:border-transparent"
              />
            </div>
          </div>

          {/* Save Button */}
          <div className="flex items-center justify-between pt-4 border-t border-border-light">
            <button
              onClick={handleSaveProfile}
              className="px-6 py-3 bg-byzantine hover:bg-byzantine-dark text-white font-semibold rounded-lg transition-colors"
            >
              {t.settings.save}
            </button>
            {saveMessage && (
              <motion.span
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-sm text-green-600 font-medium"
              >
                {saveMessage}
              </motion.span>
            )}
          </div>
        </motion.div>

        {/* B. Payout Preferences */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="glass-card p-8 space-y-6"
        >
          <h2 className="text-xl font-semibold text-text-primary">{t.settings.payoutPreferences}</h2>

          {/* Payout Method Selection */}
          <div className="space-y-4">
            <label className="block text-sm font-medium text-text-primary mb-3">{t.settings.payoutMethod}</label>

            <div className="space-y-3">
              {/* Bank Transfer */}
              <div className="flex items-start gap-4 p-4 border border-border rounded-lg cursor-pointer hover:bg-surface-hover transition-colors"
                onClick={() => setPayoutMethod('bank_transfer')}>
                <div className="flex items-center mt-1">
                  <input
                    type="radio"
                    name="payoutMethod"
                    value="bank_transfer"
                    checked={payoutMethod === 'bank_transfer'}
                    onChange={() => setPayoutMethod('bank_transfer')}
                    className="w-4 h-4 cursor-pointer"
                  />
                </div>
                <div className="flex-1">
                  <p className="font-medium text-text-primary">{t.settings.bankTransfer}</p>
                  <p className="text-sm text-text-secondary">Direct transfer to your bank account</p>
                </div>
              </div>

              {/* Byzantine Prime */}
              <div className="flex items-start gap-4 p-4 border border-border rounded-lg cursor-pointer hover:bg-surface-hover transition-colors"
                onClick={() => setPayoutMethod('byzantine_prime')}>
                <div className="flex items-center mt-1">
                  <input
                    type="radio"
                    name="payoutMethod"
                    value="byzantine_prime"
                    checked={payoutMethod === 'byzantine_prime'}
                    onChange={() => setPayoutMethod('byzantine_prime')}
                    className="w-4 h-4 cursor-pointer"
                  />
                </div>
                <div className="flex-1">
                  <p className="font-medium text-text-primary">Byzantine Prime Account</p>
                  <p className="text-sm text-text-secondary">Credit to your Byzantine Prime account for instant reinvestment</p>
                </div>
              </div>
            </div>
          </div>

          {/* Bank Details (shown if bank transfer selected) */}
          {payoutMethod === 'bank_transfer' && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              transition={{ duration: 0.3 }}
              className="pt-6 border-t border-border-light space-y-4"
            >
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-text-primary mb-2">{t.settings.iban}</label>
                  <input
                    type="text"
                    value={bankDetails.iban}
                    onChange={(e) => handleBankDetailsChange('iban', e.target.value)}
                    className="w-full px-4 py-3 bg-surface border border-border rounded-lg text-text-primary font-mono text-sm focus:outline-none focus:ring-2 focus:ring-byzantine focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-text-primary mb-2">{t.settings.bic}</label>
                  <input
                    type="text"
                    value={bankDetails.bic}
                    onChange={(e) => handleBankDetailsChange('bic', e.target.value)}
                    className="w-full px-4 py-3 bg-surface border border-border rounded-lg text-text-primary font-mono text-sm focus:outline-none focus:ring-2 focus:ring-byzantine focus:border-transparent"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-text-primary mb-2">{t.settings.bankName}</label>
                <input
                  type="text"
                  value={bankDetails.bankName}
                  onChange={(e) => handleBankDetailsChange('bankName', e.target.value)}
                  className="w-full px-4 py-3 bg-surface border border-border rounded-lg text-text-primary focus:outline-none focus:ring-2 focus:ring-byzantine focus:border-transparent"
                />
              </div>

              {/* Preview */}
              <div className="mt-6 p-4 bg-surface-secondary rounded-lg border border-border-light">
                <p className="text-xs text-text-muted uppercase tracking-wide font-semibold mb-2">Preview</p>
                <p className="text-sm text-text-primary">
                  Your next commission payment of <span className="font-semibold">€18,275</span> will be sent via bank transfer to <span className="font-semibold">{bankDetails.bankName || 'your bank'}</span>
                </p>
              </div>
            </motion.div>
          )}

          {payoutMethod === 'byzantine_prime' && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3 }}
              className="pt-6 border-t border-border-light"
            >
              <div className="p-4 bg-surface-secondary rounded-lg border border-border-light">
                <p className="text-sm text-text-primary">
                  Your next commission payment of <span className="font-semibold">€18,275</span> will be credited to your Byzantine Prime account and can be reinvested immediately.
                </p>
              </div>
            </motion.div>
          )}
        </motion.div>

        {/* C. Notification Preferences */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="glass-card p-8 space-y-6"
        >
          <h2 className="text-xl font-semibold text-text-primary">Notification Preferences</h2>

          <div className="space-y-4">
            {/* New Client Deposits */}
            <div className="flex items-start justify-between p-4 border border-border rounded-lg hover:bg-surface-hover transition-colors">
              <div className="flex-1">
                <p className="font-medium text-text-primary">Email alerts for new client deposits</p>
                <p className="text-sm text-text-secondary">Get notified when a client makes a deposit</p>
              </div>
              <button
                onClick={() => handleNotificationToggle('newDeposits')}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  notifications.newDeposits ? 'bg-green-500' : 'bg-gray-300'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    notifications.newDeposits ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            {/* Withdrawals */}
            <div className="flex items-start justify-between p-4 border border-border rounded-lg hover:bg-surface-hover transition-colors">
              <div className="flex-1">
                <p className="font-medium text-text-primary">Email alerts for client withdrawals</p>
                <p className="text-sm text-text-secondary">Get notified when a client withdraws funds</p>
              </div>
              <button
                onClick={() => handleNotificationToggle('withdrawals')}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  notifications.withdrawals ? 'bg-green-500' : 'bg-gray-300'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    notifications.withdrawals ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            {/* Payout Notifications */}
            <div className="flex items-start justify-between p-4 border border-border rounded-lg hover:bg-surface-hover transition-colors">
              <div className="flex-1">
                <p className="font-medium text-text-primary">Commission payout notifications</p>
                <p className="text-sm text-text-secondary">Get notified when your quarterly commission is paid</p>
              </div>
              <button
                onClick={() => handleNotificationToggle('payoutNotifications')}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  notifications.payoutNotifications ? 'bg-green-500' : 'bg-gray-300'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    notifications.payoutNotifications ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            {/* Monthly Summary */}
            <div className="flex items-start justify-between p-4 border border-border rounded-lg hover:bg-surface-hover transition-colors">
              <div className="flex-1">
                <p className="font-medium text-text-primary">Monthly summary report</p>
                <p className="text-sm text-text-secondary">Receive a comprehensive monthly overview of your pipeline</p>
              </div>
              <button
                onClick={() => handleNotificationToggle('monthlySummary')}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  notifications.monthlySummary ? 'bg-green-500' : 'bg-gray-300'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    notifications.monthlySummary ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            {/* Weekly Pipeline Digest */}
            <div className="flex items-start justify-between p-4 border border-border rounded-lg hover:bg-surface-hover transition-colors">
              <div className="flex-1">
                <p className="font-medium text-text-primary">Weekly pipeline digest</p>
                <p className="text-sm text-text-secondary">Get a weekly update on your client pipeline progress</p>
              </div>
              <button
                onClick={() => handleNotificationToggle('weeklyPipeline')}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  notifications.weeklyPipeline ? 'bg-green-500' : 'bg-gray-300'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    notifications.weeklyPipeline ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>
          </div>
        </motion.div>

        {/* D. Language */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="glass-card p-8 space-y-6"
        >
          <h2 className="text-xl font-semibold text-text-primary">{t.settings.language}</h2>

          <div className="grid grid-cols-2 gap-4">
            <button
              onClick={() => setLocale('en')}
              className={`p-4 rounded-lg border-2 font-semibold transition-all ${
                locale === 'en'
                  ? 'border-byzantine bg-byzantine-50 text-byzantine'
                  : 'border-border text-text-primary hover:border-byzantine-200'
              }`}
            >
              {t.settings.english}
            </button>
            <button
              onClick={() => setLocale('fr')}
              className={`p-4 rounded-lg border-2 font-semibold transition-all ${
                locale === 'fr'
                  ? 'border-byzantine bg-byzantine-50 text-byzantine'
                  : 'border-border text-text-primary hover:border-byzantine-200'
              }`}
            >
              {t.settings.french}
            </button>
          </div>
        </motion.div>

        {/* E. Support & Help */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="glass-card p-8 space-y-6"
        >
          <h2 className="text-xl font-semibold text-text-primary">Support & Help</h2>

          <div className="space-y-4">
            <div className="p-4 bg-surface-secondary rounded-lg">
              <p className="text-sm text-text-muted mb-2">Support contact</p>
              <a
                href="mailto:support@byzantine.finance"
                className="text-byzantine hover:text-byzantine-dark font-semibold text-base transition-colors"
              >
                support@byzantine.finance
              </a>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <a
                href="#"
                className="p-4 border border-border rounded-lg hover:bg-surface-hover transition-colors group"
              >
                <p className="font-medium text-text-primary mb-1 group-hover:text-byzantine transition-colors">Documentation</p>
                <p className="text-xs text-text-muted">View API & partner docs</p>
              </a>

              <a
                href="#"
                className="p-4 border border-border rounded-lg hover:bg-surface-hover transition-colors group"
              >
                <p className="font-medium text-text-primary mb-1 group-hover:text-byzantine transition-colors">FAQ</p>
                <p className="text-xs text-text-muted">Common questions</p>
              </a>
            </div>

            <div className="pt-4 border-t border-border-light">
              <p className="text-sm text-text-muted mb-2">Your account manager</p>
              <div>
                <p className="font-semibold text-text-primary">Gaia Ferrero Regis</p>
                <a
                  href="mailto:gaia@byzantine.finance"
                  className="text-byzantine hover:text-byzantine-dark text-sm transition-colors"
                >
                  gaia@byzantine.finance
                </a>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}

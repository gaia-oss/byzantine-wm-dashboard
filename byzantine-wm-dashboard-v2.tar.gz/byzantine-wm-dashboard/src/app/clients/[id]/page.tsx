'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { ArrowLeft, Edit2, Save, X } from 'lucide-react';
import { useI18n } from '@/i18n/context';
import { StatusBadge } from '@/components/ui/StatusBadge';
import { KpiCard } from '@/components/ui/KpiCard';
import { AumChart } from '@/components/charts/AumChart';
import { SkeletonTable } from '@/components/ui/Skeleton';
import type { ClientDetail } from '@/types';
import { fetchClientById, updateClientFee } from '@/lib/services';

interface ClientDetailPageProps {
  params: {
    id: string;
  };
}

export default function ClientDetailPage({ params }: ClientDetailPageProps) {
  const { t } = useI18n();
  const [client, setClient] = useState<ClientDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [editingFee, setEditingFee] = useState(false);
  const [newFee, setNewFee] = useState<number | ''>('');

  // Load client data on mount
  useEffect(() => {
    const loadClient = async () => {
      try {
        const clientData = await fetchClientById(params.id);
        setClient(clientData);
        setNewFee(clientData.managementFee);
      } catch (err) {
        setError('Client not found');
        console.error('Failed to load client:', err);
      } finally {
        setLoading(false);
      }
    };

    loadClient();
  }, [params.id]);

  // Format currency
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: 'EUR',
      maximumFractionDigits: 0,
    }).format(amount);
  };

  // Calculate annual fee income
  const calculateAnnualFee = (aum: number, feeBps: number) => {
    return (aum * feeBps) / 10000;
  };

  // Format date
  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('fr-FR', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  // Handle fee update
  const handleSaveFee = async () => {
    if (!client || newFee === '') return;

    try {
      const updatedClient = await updateClientFee(client.id, Number(newFee));
      setClient({ ...client, managementFee: updatedClient.managementFee });
      setEditingFee(false);
    } catch (err) {
      console.error('Failed to update fee:', err);
    }
  };

  // Handle fee cancel
  const handleCancelFee = () => {
    setNewFee(client?.managementFee || '');
    setEditingFee(false);
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-[#1A0918] mb-2">{t.clients.name}</h1>
        </div>
        <SkeletonTable />
      </div>
    );
  }

  if (error || !client) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.3 }}
        className="space-y-6"
      >
        <Link
          href="/clients"
          className="inline-flex items-center gap-2 text-[#702963] hover:text-[#5A1F4F] font-medium"
        >
          <ArrowLeft size={18} />
          Back to clients
        </Link>

        <div className="glass-card p-8 text-center">
          <p className="text-[#9B8FA0] text-lg">{error || 'Client not found'}</p>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
      className="space-y-6"
    >
      {/* Back Button */}
      <Link
        href="/clients"
        className="inline-flex items-center gap-2 text-[#702963] hover:text-[#5A1F4F] font-medium transition-colors"
      >
        <ArrowLeft size={18} />
        Back to clients
      </Link>

      {/* Client Header */}
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.1 }}
        className="glass-card p-6"
      >
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <h1 className="text-3xl font-bold text-[#1A0918] mb-2">{client.name}</h1>
            <p className="text-[#6B5A70] mb-4">{client.email}</p>
            <div className="flex flex-wrap gap-3">
              <span className="text-xs px-3 py-1.5 bg-[#F3EFF5] text-[#6B5A70] rounded capitalize font-medium">
                {client.type === 'individual' ? 'Individual' : 'Business'}
              </span>
              <StatusBadge status={client.status} />
              <span className="text-xs px-3 py-1.5 bg-[#E8E0EC] text-[#6B5A70] rounded font-medium">
                Joined {formatDate(client.joinDate)}
              </span>
            </div>
          </div>
        </div>
      </motion.div>

      {/* KPI Cards */}
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.15 }}
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4"
      >
        <KpiCard
          title="Current Balance"
          value={formatCurrency(client.aum)}
        />
        <KpiCard
          title="Avg Quarterly AUM"
          value={formatCurrency(client.aum)}
        />
        <KpiCard
          title="Commission Earned"
          value={formatCurrency(
            client.commissionHistory?.reduce((sum, payout) => sum + payout.amount, 0) || 0
          )}
        />
        <KpiCard
          title="Current Yield"
          value={`${(((client.managementFee || 0) / 10000) * 100).toFixed(2)}%`}
        />
      </motion.div>

      {/* Commission Tier Info */}
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.2 }}
        className="glass-card p-6"
      >
        <h3 className="text-lg font-semibold text-[#1A0918] mb-6">Commission Structure</h3>

        {/* Get tier info */}
        {(() => {
          const getTierInfo = (tier: number) => {
            const tiers: Record<number, { year1: number; year2: number; year3: number; timeToYear2: string }> = {
              1: { year1: 28, year2: 12, year3: 10, timeToYear2: '8 months' },
              2: { year1: 28, year2: 12, year3: 10, timeToYear2: '8 months' },
              3: { year1: 36, year2: 16, year3: 12, timeToYear2: '8 months' },
              4: { year1: 40, year2: 20, year3: 15, timeToYear2: '8 months' },
            };
            return tiers[tier] || tiers[1];
          };

          const tierInfo = getTierInfo(client.commissionTier);
          const currentYear = client.commissionTier;

          return (
            <div className="space-y-4">
              <p className="text-[#6B5A70]">
                Year {currentYear} — {tierInfo.year1} bps. Steps to {tierInfo.year2} bps in {tierInfo.timeToYear2}
              </p>

              {/* Visual Timeline */}
              <div className="flex items-center gap-4">
                <div className="flex-1 flex items-center">
                  <div className="flex-1 h-8 bg-[#702963] rounded-l-lg flex items-center justify-center">
                    <span className="text-white font-bold text-sm">Year 1</span>
                  </div>
                  <div className="px-2 text-[#6B5A70] font-medium text-sm">→</div>
                  <div className="flex-1 h-8 bg-[#D4A5D4] rounded-lg flex items-center justify-center">
                    <span className="text-[#1A0918] font-bold text-sm">Year 2</span>
                  </div>
                  <div className="px-2 text-[#6B5A70] font-medium text-sm">→</div>
                  <div className="flex-1 h-8 bg-[#E8D4E8] rounded-r-lg flex items-center justify-center">
                    <span className="text-[#1A0918] font-bold text-sm">Year 3</span>
                  </div>
                </div>
              </div>

              {/* Tier Details */}
              <div className="grid grid-cols-3 gap-4 mt-6">
                <div className="text-center p-4 bg-[#F3EFF5] rounded-lg">
                  <p className="text-sm text-[#6B5A70] mb-2">Year 1</p>
                  <p className="text-2xl font-bold text-[#702963]">{tierInfo.year1} bps</p>
                </div>
                <div className="text-center p-4 bg-[#F3EFF5] rounded-lg">
                  <p className="text-sm text-[#6B5A70] mb-2">Year 2</p>
                  <p className="text-2xl font-bold text-[#702963]">{tierInfo.year2} bps</p>
                </div>
                <div className="text-center p-4 bg-[#F3EFF5] rounded-lg">
                  <p className="text-sm text-[#6B5A70] mb-2">Year 3+</p>
                  <p className="text-2xl font-bold text-[#702963]">{tierInfo.year3} bps</p>
                </div>
              </div>
            </div>
          );
        })()}
      </motion.div>

      {/* Fee Adjustment Section */}
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.25 }}
        className="glass-card p-6"
      >
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-[#1A0918]">Management Fee</h3>
          {!editingFee && (
            <button
              onClick={() => setEditingFee(true)}
              className="inline-flex items-center gap-2 px-3 py-1.5 text-sm font-medium text-[#702963] hover:bg-[#F3EFF5] rounded-lg transition-colors"
            >
              <Edit2 size={16} />
              Edit
            </button>
          )}
        </div>

        {!editingFee ? (
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-[#F8F6FA] rounded-lg border border-[#E8E0EC]">
              <span className="text-[#6B5A70]">Current management fee:</span>
              <span className="text-xl font-bold text-[#1A0918]">{client.managementFee} bps</span>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <div className="flex-1">
                <label className="text-sm font-medium text-[#6B5A70] mb-2 block">
                  New Management Fee (bps)
                </label>
                <input
                  type="number"
                  min="0"
                  max="1000"
                  value={newFee}
                  onChange={(e) => setNewFee(e.target.value === '' ? '' : Number(e.target.value))}
                  className="w-full px-4 py-2.5 bg-[#F8F6FA] border border-[#E8E0EC] rounded-lg text-[#1A0918] focus:outline-none focus:border-[#702963] focus:ring-1 focus:ring-[#702963]"
                  placeholder="Enter fee in bps"
                />
              </div>
            </div>

            {/* Fee Preview */}
            {newFee !== '' && (
              <div className="p-4 bg-[#F3EFF5] rounded-lg border border-[#E8E0EC] space-y-2">
                <p className="text-sm text-[#6B5A70]">Preview</p>
                <div className="space-y-1">
                  <div className="flex justify-between text-sm">
                    <span className="text-[#6B5A70]">Client AUM:</span>
                    <span className="font-medium text-[#1A0918]">{formatCurrency(client.aum)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-[#6B5A70]">Your fee:</span>
                    <span className="font-medium text-[#1A0918]">{newFee} bps</span>
                  </div>
                  <div className="border-t border-[#E8E0EC] pt-2 flex justify-between">
                    <span className="text-[#1A0918] font-medium">Annual fee income:</span>
                    <span className="font-bold text-[#702963]">
                      {formatCurrency(calculateAnnualFee(client.aum, Number(newFee)))}
                    </span>
                  </div>
                </div>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex gap-3 justify-end">
              <button
                onClick={handleCancelFee}
                className="inline-flex items-center gap-2 px-4 py-2 border border-[#E8E0EC] text-[#1A0918] rounded-lg font-medium hover:bg-[#F8F6FA] transition-colors"
              >
                <X size={18} />
                Cancel
              </button>
              <button
                onClick={handleSaveFee}
                className="inline-flex items-center gap-2 px-4 py-2 bg-[#702963] text-white rounded-lg font-medium hover:bg-[#5A1F4F] transition-colors"
              >
                <Save size={18} />
                Save Changes
              </button>
            </div>
          </div>
        )}
      </motion.div>

      {/* AUM Chart */}
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.3 }}
      >
        <AumChart data={client.aumHistory} />
      </motion.div>

      {/* Transaction History */}
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.35 }}
        className="glass-card overflow-hidden"
      >
        <div className="p-6 border-b border-[#E8E0EC]">
          <h3 className="text-lg font-semibold text-[#1A0918]">Transaction History</h3>
        </div>

        {client.transactions && client.transactions.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="data-table w-full">
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Type</th>
                  <th>Amount</th>
                  <th>Status</th>
                  <th>Reference ID</th>
                </tr>
              </thead>
              <tbody>
                {client.transactions.map((tx, index) => (
                  <motion.tr
                    key={tx.id}
                    initial={{ opacity: 0, y: 4 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.2, delay: index * 0.02 }}
                    className="hover:bg-[#F3EFF5] transition-colors"
                  >
                    <td className="text-sm text-[#6B5A70]">
                      {formatDate(tx.date)}
                    </td>
                    <td>
                      <span className="text-sm font-medium capitalize">
                        {tx.type}
                      </span>
                    </td>
                    <td className="font-medium text-[#1A0918]">
                      {formatCurrency(tx.amount)}
                    </td>
                    <td>
                      <span className={`text-xs px-2 py-1 rounded font-medium ${
                        tx.status === 'completed'
                          ? 'bg-[#D4EDDA] text-[#155724]'
                          : tx.status === 'pending'
                          ? 'bg-[#FFF3CD] text-[#856404]'
                          : 'bg-[#F8D7DA] text-[#721C24]'
                      }`}>
                        {tx.status.charAt(0).toUpperCase() + tx.status.slice(1)}
                      </span>
                    </td>
                    <td className="text-xs text-[#9B8FA0] font-mono">{tx.id}</td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="p-8 text-center text-[#9B8FA0]">
            No transactions found
          </div>
        )}
      </motion.div>

      {/* Quarterly Commission History */}
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.4 }}
        className="glass-card overflow-hidden"
      >
        <div className="p-6 border-b border-[#E8E0EC]">
          <h3 className="text-lg font-semibold text-[#1A0918]">Commission History</h3>
        </div>

        {client.commissionHistory && client.commissionHistory.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="data-table w-full">
              <thead>
                <tr>
                  <th>Quarter</th>
                  <th>Period</th>
                  <th>Amount</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {client.commissionHistory.map((payout, index) => (
                  <motion.tr
                    key={`${payout.quarter}-${payout.year}`}
                    initial={{ opacity: 0, y: 4 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.2, delay: index * 0.02 }}
                    className="hover:bg-[#F3EFF5] transition-colors"
                  >
                    <td className="font-medium text-[#1A0918]">
                      {payout.quarter} {payout.year}
                    </td>
                    <td className="text-sm text-[#6B5A70]">
                      {payout.paidDate ? new Date(payout.paidDate).toLocaleDateString('fr-FR') : 'Pending'}
                    </td>
                    <td className="font-medium text-[#702963]">
                      {formatCurrency(payout.amount)}
                    </td>
                    <td>
                      <span className={`text-xs px-2 py-1 rounded font-medium ${
                        payout.status === 'paid'
                          ? 'bg-[#D4EDDA] text-[#155724]'
                          : payout.status === 'pending'
                          ? 'bg-[#FFF3CD] text-[#856404]'
                          : 'bg-[#E8E0EC] text-[#6B5A70]'
                      }`}>
                        {payout.status.charAt(0).toUpperCase() + payout.status.slice(1)}
                      </span>
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="p-8 text-center text-[#9B8FA0]">
            No commission history found
          </div>
        )}
      </motion.div>
    </motion.div>
  );
}

'use client';

import React, { useState, useMemo, useCallback } from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { Search, Download, Plus } from 'lucide-react';
import { useI18n } from '@/i18n/context';
import { FunnelPills } from '@/components/ui/FunnelPills';
import { StatusBadge } from '@/components/ui/StatusBadge';
import { SkeletonTable } from '@/components/ui/Skeleton';
import type { Client, ClientFunnelData } from '@/types';
import { fetchClients, fetchClientFunnel } from '@/lib/services';

type SortField = 'name' | 'aum' | 'tier' | 'commission' | 'lastActivity';
type SortDirection = 'asc' | 'desc';

interface ClientWithQuarterlyCommission extends Client {
  quarterlyCommission: number;
  avgQuarterlyAum: number;
}

export default function ClientsPage() {
  const { t } = useI18n();
  const [clients, setClients] = useState<ClientWithQuarterlyCommission[]>([]);
  const [funnel, setFunnel] = useState<ClientFunnelData | null>(null);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState<'all' | 'individual' | 'business'>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [funnelFilter, setFunnelFilter] = useState<string | null>(null);
  const [sortField, setSortField] = useState<SortField>('name');
  const [sortDirection, setSortDirection] = useState<SortDirection>('asc');

  // Load data on mount
  React.useEffect(() => {
    const loadData = async () => {
      try {
        const [clientsData, funnelData] = await Promise.all([
          fetchClients(),
          fetchClientFunnel(),
        ]);

        // Calculate quarterly commission and average quarterly AUM
        const clientsWithCommission = clientsData.map((client) => {
          const avgQuarterlyAum = client.aum;
          const tierBps = getTierBps(client.aum, client.commissionTier);
          const quarterlyCommission = (avgQuarterlyAum * tierBps) / 10000;

          return {
            ...client,
            quarterlyCommission,
            avgQuarterlyAum,
          };
        });

        setClients(clientsWithCommission);
        setFunnel(funnelData);
      } catch (error) {
        console.error('Failed to load clients:', error);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, []);

  // Get commission tier bps based on AUM and year
  const getTierBps = (aum: number, year: number): number => {
    if (aum < 1000000) {
      return year === 1 ? 28 : year === 2 ? 12 : 10;
    } else if (aum < 5000000) {
      return year === 1 ? 28 : year === 2 ? 12 : 10;
    } else if (aum < 10000000) {
      return year === 1 ? 36 : year === 2 ? 16 : 12;
    }
    return year === 1 ? 40 : year === 2 ? 20 : 15;
  };

  // Format currency
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: 'EUR',
      maximumFractionDigits: 0,
    }).format(amount);
  };

  // Format relative date
  const formatRelativeDate = (dateStr: string) => {
    const date = new Date(dateStr);
    const now = new Date();
    const daysAgo = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24));

    if (daysAgo === 0) return 'Today';
    if (daysAgo === 1) return 'Yesterday';
    if (daysAgo < 7) return `${daysAgo}d ago`;
    if (daysAgo < 30) return `${Math.floor(daysAgo / 7)}w ago`;
    if (daysAgo < 365) return `${Math.floor(daysAgo / 30)}m ago`;
    return `${Math.floor(daysAgo / 365)}y ago`;
  };

  // Handle funnel filter change
  const handleFunnelChange = useCallback((stage: string | null) => {
    setFunnelFilter(stage);
  }, []);

  // Filter and sort clients
  const filteredAndSortedClients = useMemo(() => {
    let filtered = [...clients];

    // Apply search filter
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(
        (client) =>
          client.name.toLowerCase().includes(term) ||
          client.email.toLowerCase().includes(term) ||
          client.id.toLowerCase().includes(term)
      );
    }

    // Apply type filter
    if (typeFilter !== 'all') {
      filtered = filtered.filter((client) => client.type === typeFilter);
    }

    // Apply status filter
    if (statusFilter !== 'all') {
      filtered = filtered.filter((client) => client.status === statusFilter);
    }

    // Apply funnel filter
    if (funnelFilter) {
      filtered = filtered.filter((client) => {
        const funneMap: Record<string, string[]> = {
          total: ['invited', 'kyc_pending', 'kyc_approved', 'first_deposit', 'active', 'cancelled'],
          invited: ['invited'],
          kycPending: ['kyc_pending'],
          kycApproved: ['kyc_approved'],
          firstDeposit: ['first_deposit'],
          active: ['active'],
          cancelled: ['cancelled'],
        };
        return funneMap[funnelFilter]?.includes(client.status) || false;
      });
    }

    // Apply sorting
    filtered.sort((a, b) => {
      let aVal: any;
      let bVal: any;

      if (sortField === 'commission') {
        aVal = a.quarterlyCommission;
        bVal = b.quarterlyCommission;
      } else if (sortField === 'tier') {
        aVal = a.commissionTier;
        bVal = b.commissionTier;
      } else {
        aVal = (a as any)[sortField];
        bVal = (b as any)[sortField];
      }

      if (typeof aVal === 'string') {
        return sortDirection === 'asc' ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
      }

      return sortDirection === 'asc' ? aVal - bVal : bVal - aVal;
    });

    return filtered;
  }, [clients, searchTerm, typeFilter, statusFilter, funnelFilter, sortField, sortDirection]);

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const SortIndicator = ({ field }: { field: SortField }) => {
    if (sortField !== field) return null;
    return (
      <span className="ml-2 text-[#702963]">
        {sortDirection === 'asc' ? '↑' : '↓'}
      </span>
    );
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-[#1A0918] mb-2">{t.clients.title}</h1>
          <p className="text-[#6B5A70]">{t.clients.subtitle}</p>
        </div>
        <SkeletonTable />
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
      className="space-y-6"
    >
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-[#1A0918] mb-2">{t.clients.title}</h1>
        <p className="text-[#6B5A70]">{t.clients.subtitle}</p>
      </div>

      {/* Funnel Pills */}
      {funnel && (
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.1 }}
        >
          <FunnelPills data={funnel} onFilterChange={handleFunnelChange} />
        </motion.div>
      )}

      {/* Filters and Actions */}
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.15 }}
        className="glass-card p-4 space-y-4"
      >
        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-3 text-[#9B8FA0]" size={18} />
          <input
            type="text"
            placeholder={t.clients.search}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-[#F8F6FA] border border-[#E8E0EC] rounded-lg text-[#1A0918] placeholder-[#9B8FA0] focus:outline-none focus:border-[#702963] focus:ring-1 focus:ring-[#702963]"
          />
        </div>

        {/* Filter Row */}
        <div className="flex flex-wrap gap-4">
          {/* Type Filter */}
          <div className="flex items-center gap-2">
            <label className="text-sm font-medium text-[#6B5A70]">{t.clients.type}:</label>
            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value as any)}
              className="px-3 py-2 bg-[#F8F6FA] border border-[#E8E0EC] rounded-lg text-sm text-[#1A0918] focus:outline-none focus:border-[#702963]"
            >
              <option value="all">{t.clients.all}</option>
              <option value="individual">{t.clients.individuals}</option>
              <option value="business">{t.clients.businesses}</option>
            </select>
          </div>

          {/* Status Filter */}
          <div className="flex items-center gap-2">
            <label className="text-sm font-medium text-[#6B5A70]">{t.clients.status}:</label>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-3 py-2 bg-[#F8F6FA] border border-[#E8E0EC] rounded-lg text-sm text-[#1A0918] focus:outline-none focus:border-[#702963]"
            >
              <option value="all">{t.clients.allStatuses}</option>
              <option value="invited">{t.funnel.invited}</option>
              <option value="kyc_pending">{t.funnel.kycPending}</option>
              <option value="kyc_approved">{t.funnel.kycApproved}</option>
              <option value="first_deposit">{t.funnel.firstDeposit}</option>
              <option value="active">{t.funnel.active}</option>
              <option value="cancelled">{t.funnel.cancelled}</option>
            </select>
          </div>

          {/* Action Buttons */}
          <div className="ml-auto flex gap-3">
            <Link
              href="/pipeline"
              className="inline-flex items-center gap-2 px-4 py-2 bg-[#702963] text-white rounded-lg font-medium hover:bg-[#5A1F4F] transition-colors"
            >
              <Plus size={18} />
              Invite client
            </Link>
            <button className="inline-flex items-center gap-2 px-4 py-2 border border-[#E8E0EC] text-[#1A0918] rounded-lg font-medium hover:bg-[#F8F6FA] transition-colors">
              <Download size={18} />
              Export CSV
            </button>
          </div>
        </div>
      </motion.div>

      {/* Clients Table */}
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.2 }}
        className="glass-card overflow-hidden"
      >
        {filteredAndSortedClients.length === 0 ? (
          <div className="p-8 text-center text-[#9B8FA0]">
            {t.clients.noClients}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="data-table w-full">
              <thead>
                <tr>
                  <th
                    onClick={() => handleSort('name')}
                    className="cursor-pointer hover:bg-[#F3EFF5] select-none"
                  >
                    {t.clients.name}
                    <SortIndicator field="name" />
                  </th>
                  <th>{t.clients.type}</th>
                  <th>Status</th>
                  <th
                    onClick={() => handleSort('aum')}
                    className="cursor-pointer hover:bg-[#F3EFF5] select-none"
                  >
                    {t.clients.aum}
                    <SortIndicator field="aum" />
                  </th>
                  <th>Avg Quarterly AUM</th>
                  <th>Commission Tier</th>
                  <th
                    onClick={() => handleSort('commission')}
                    className="cursor-pointer hover:bg-[#F3EFF5] select-none"
                  >
                    Quarterly Commission
                    <SortIndicator field="commission" />
                  </th>
                  <th
                    onClick={() => handleSort('lastActivity')}
                    className="cursor-pointer hover:bg-[#F3EFF5] select-none"
                  >
                    {t.clients.lastActivity}
                    <SortIndicator field="lastActivity" />
                  </th>
                </tr>
              </thead>
              <tbody>
                {filteredAndSortedClients.map((client, index) => (
                  <motion.tr
                    key={client.id}
                    initial={{ opacity: 0, y: 4 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.2, delay: index * 0.02 }}
                    className="hover:bg-[#F3EFF5] cursor-pointer transition-colors"
                    onClick={() => window.location.href = `/clients/${client.id}`}
                  >
                    <td className="font-medium">
                      <div className="font-semibold text-[#1A0918]">{client.name}</div>
                      <div className="text-xs text-[#9B8FA0]">{client.email}</div>
                    </td>
                    <td>
                      <span className="text-sm px-2 py-1 bg-[#F3EFF5] text-[#6B5A70] rounded capitalize">
                        {client.type === 'individual' ? 'Individual' : 'Business'}
                      </span>
                    </td>
                    <td>
                      <StatusBadge status={client.status} />
                    </td>
                    <td className="font-medium text-[#1A0918]">
                      {client.aum > 0 ? formatCurrency(client.aum) : '—'}
                    </td>
                    <td className="text-[#6B5A70]">
                      {client.avgQuarterlyAum > 0 ? formatCurrency(client.avgQuarterlyAum) : '—'}
                    </td>
                    <td>
                      <span className="text-xs px-2 py-1 bg-[#E0B3D9] text-[#702963] rounded font-medium">
                        Year {client.commissionTier}
                      </span>
                    </td>
                    <td className="font-medium text-[#702963]">
                      {client.quarterlyCommission > 0 ? formatCurrency(client.quarterlyCommission) : '—'}
                    </td>
                    <td className="text-[#6B5A70] text-sm">
                      {formatRelativeDate(client.lastActivity)}
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </motion.div>
    </motion.div>
  );
}

'use client';

import React, { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { KpiCard } from '@/components/ui/KpiCard';
import { useI18n } from '@/i18n/context';
import { fetchDashboardKPIs, fetchCommissionBreakdown, getCommissionTiers, fetchClients } from '@/lib/services';
import { COMMISSION_TIERS } from '@/lib/mock-data';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.2,
    },
  },
};

const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0, transition: { duration: 0.3 } },
};

function formatEur(value: number): string {
  return new Intl.NumberFormat('fr-FR', {
    style: 'currency',
    currency: 'EUR',
    minimumFractionDigits: 0,
  }).format(value);
}

function formatBps(value: number): string {
  return `${value} bps`;
}

export default function CommissionsPage() {
  const { t } = useI18n();
  const [projectedAum, setProjectedAum] = useState(50000000);
  const [kpis, setKpis] = useState<any>(null);
  const [breakdown, setBreakdown] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // Fetch data on mount
  React.useEffect(() => {
    async function loadData() {
      try {
        const [kpiData, breakdownData] = await Promise.all([
          fetchDashboardKPIs(),
          fetchCommissionBreakdown(),
        ]);
        setKpis(kpiData);
        setBreakdown(breakdownData);
      } catch (error) {
        console.error('Failed to load commission data:', error);
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, []);

  // Calculate projected earnings by tier
  const projectedEarnings = useMemo(() => {
    const tiers = [
      { range: '50K-1M', limit: 1000000, y1: 28, y2: 12, y3: 10 },
      { range: '1M-5M', limit: 5000000, y1: 28, y2: 12, y3: 10 },
      { range: '5M-10M', limit: 10000000, y1: 36, y2: 16, y3: 12 },
      { range: '10M+', limit: Infinity, y1: 40, y2: 20, y3: 15 },
    ];

    let remaining = projectedAum;
    let year1Total = 0;
    let year2Total = 0;
    let year3Total = 0;

    for (const tier of tiers) {
      if (remaining <= 0) break;
      const tierMin = tiers.indexOf(tier) === 0 ? 50000 : tiers[tiers.indexOf(tier) - 1].limit;
      const tierMax = tier.limit;
      const tierRange = remaining;
      const tierAum = Math.min(tierRange, tierMax - tierMin);

      year1Total += (tierAum * tier.y1) / 10000;
      year2Total += (tierAum * tier.y2) / 10000;
      year3Total += (tierAum * tier.y3) / 10000;

      remaining -= tierAum;
    }

    return {
      year1: year1Total,
      year2: year2Total,
      year3: year3Total,
    };
  }, [projectedAum]);

  const chartData = [
    {
      name: 'Projected Annual Earnings',
      'Year 1': Math.round(projectedEarnings.year1),
      'Year 2': Math.round(projectedEarnings.year2),
      'Year 3+': Math.round(projectedEarnings.year3),
    },
  ];

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-[#9B8FA0]">{t.common.loading}</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-12">
      <div className="space-y-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="pt-8"
        >
          <h1 className="text-3xl font-bold text-[#1A0918] mb-2">{t.commissions.title}</h1>
          <p className="text-[#6B5A70]">{t.commissions.subtitle}</p>
        </motion.div>

        {/* Earnings Summary Cards */}
        <motion.div
          variants={container}
          initial="hidden"
          animate="show"
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4"
        >
          <motion.div variants={item}>
            <KpiCard
              title="Total Earned (Lifetime)"
              value={formatEur(kpis?.lifetimeEarnings || 47575)}
              subtitle="All-time earnings"
            />
          </motion.div>
          <motion.div variants={item}>
            <KpiCard
              title="Earned This Year"
              value={formatEur(kpis?.yearToDateEarnings || 36825)}
              subtitle="Year-to-date"
            />
          </motion.div>
          <motion.div variants={item}>
            <KpiCard
              title="This Quarter (Running)"
              value={formatEur(kpis?.estimatedQuarterlyCommission || 18275)}
              subtitle="Q1 2026 estimate"
            />
          </motion.div>
          <motion.div variants={item}>
            <KpiCard
              title="Projected Next Quarter"
              value={formatEur(kpis?.projectedNextQuarter || 22850)}
              subtitle="Q2 2026 estimate"
            />
          </motion.div>
        </motion.div>

        {/* Commission Breakdown Table */}
        <motion.div variants={item} initial="hidden" animate="show" className="glass-card p-6">
          <h2 className="text-xl font-bold text-[#1A0918] mb-4">{t.commissions.clientBreakdown}</h2>
          <div className="overflow-x-auto">
            <table className="w-full data-table">
              <thead>
                <tr>
                  <th>Client Name</th>
                  <th>AUM Tier</th>
                  <th>Partnership Year</th>
                  <th>Applicable Rate</th>
                  <th>Quarterly Commission</th>
                  <th>Cumulative Earned</th>
                </tr>
              </thead>
              <tbody>
                {breakdown.map((row) => (
                  <tr key={row.clientId}>
                    <td className="font-medium">{row.clientName}</td>
                    <td className="text-[#6B5A70]">{row.tier}</td>
                    <td className="text-[#6B5A70]">
                      {row.bps === 28 || row.bps === 36 || row.bps === 40 ? 'Year 1' : 'Year 2+'}
                    </td>
                    <td className="font-semibold text-[#702963]">{formatBps(row.bps)}</td>
                    <td className="font-semibold">{formatEur(row.quarterlyEarning)}</td>
                    <td className="font-semibold text-[#16A34A]">{formatEur(row.annualizedEarning)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </motion.div>

        {/* Commission Schedule Reference */}
        <motion.div variants={item} initial="hidden" animate="show" className="glass-card p-6">
          <h2 className="text-xl font-bold text-[#1A0918] mb-4">{t.commissions.commissionTiers}</h2>
          <div className="overflow-x-auto mb-6">
            <table className="w-full data-table">
              <thead>
                <tr>
                  <th>{t.commissions.aumRange}</th>
                  <th>{t.commissions.year1}</th>
                  <th>{t.commissions.year2}</th>
                  <th>{t.commissions.year3}</th>
                </tr>
              </thead>
              <tbody>
                {COMMISSION_TIERS.map((tier) => (
                  <tr key={tier.label}>
                    <td className="font-medium">{tier.label}</td>
                    <td className="text-[#16A34A] font-semibold">{formatBps(tier.year1Bps)}</td>
                    <td className="text-[#F59E0B] font-semibold">{formatBps(tier.year2Bps)}</td>
                    <td className="text-[#2563EB] font-semibold">{formatBps(tier.year3Bps)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Info Box */}
          <div className="bg-[#F9F0F7] border border-[#E0B3D9] rounded-lg p-4 space-y-2">
            <p className="text-sm text-[#6B5A70]">
              <span className="font-semibold">Commission calculated</span> on average daily AUM over the quarter
            </p>
            <p className="text-sm text-[#6B5A70]">
              <span className="font-semibold">Deposits in last 30 days</span> of quarter are pro-rated
            </p>
            <p className="text-sm text-[#6B5A70]">
              <span className="font-semibold">10M+ clients:</span> auto-renewed, no time limit
            </p>
            <p className="text-sm text-[#6B5A70]">
              <span className="font-semibold">Below 10M:</span> 36-month term, renewable
            </p>
            <p className="text-sm text-[#6B5A70]">
              <span className="font-semibold">Payment:</span> quarterly, via bank transfer or Byzantine Prime account
            </p>
          </div>
        </motion.div>

        {/* Revenue Projection Calculator */}
        <motion.div variants={item} initial="hidden" animate="show" className="glass-card p-6">
          <h2 className="text-xl font-bold text-[#1A0918] mb-6">Revenue Projection Calculator</h2>

          <div className="space-y-6">
            {/* Slider Input */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-sm font-medium text-[#1A0918]">Expected Total AUM at Year End</label>
                <span className="text-2xl font-bold text-[#702963]">{formatEur(projectedAum)}</span>
              </div>
              <input
                type="range"
                min="1000000"
                max="100000000"
                step="1000000"
                value={projectedAum}
                onChange={(e) => setProjectedAum(Number(e.target.value))}
                className="w-full h-2 bg-[#E0B3D9] rounded-lg appearance-none cursor-pointer accent-[#702963]"
              />
              <div className="flex justify-between text-xs text-[#9B8FA0]">
                <span>€1M</span>
                <span>€100M</span>
              </div>
            </div>

            {/* Projected Earnings Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.3 }}
                className="bg-gradient-to-br from-[#16A34A] to-[#10B981] rounded-lg p-6 text-white"
              >
                <p className="text-sm font-medium opacity-90 mb-2">Year 1</p>
                <p className="text-3xl font-bold">
                  {formatEur(projectedEarnings.year1).split(' ')[0]}
                </p>
                <p className="text-xs opacity-75 mt-2">Annualized at Year 1 rates</p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.3, delay: 0.05 }}
                className="bg-gradient-to-br from-[#F59E0B] to-[#FBBF24] rounded-lg p-6 text-white"
              >
                <p className="text-sm font-medium opacity-90 mb-2">Year 2</p>
                <p className="text-3xl font-bold">
                  {formatEur(projectedEarnings.year2).split(' ')[0]}
                </p>
                <p className="text-xs opacity-75 mt-2">Annualized at Year 2 rates</p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.3, delay: 0.1 }}
                className="bg-gradient-to-br from-[#2563EB] to-[#3B82F6] rounded-lg p-6 text-white"
              >
                <p className="text-sm font-medium opacity-90 mb-2">Year 3+</p>
                <p className="text-3xl font-bold">
                  {formatEur(projectedEarnings.year3).split(' ')[0]}
                </p>
                <p className="text-xs opacity-75 mt-2">Annualized at Year 3+ rates</p>
              </motion.div>
            </div>

            {/* Chart */}
            <div className="mt-8">
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={chartData} margin={{ top: 20, right: 30, left: 0, bottom: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E0B3D9" />
                  <XAxis dataKey="name" stroke="#9B8FA0" style={{ fontSize: '0.875rem' }} />
                  <YAxis stroke="#9B8FA0" style={{ fontSize: '0.875rem' }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#FFFFFF',
                      border: '1px solid #E0B3D9',
                      borderRadius: '8px',
                    }}
                    formatter={(value) => [`€${(value as number).toLocaleString('fr-FR')}`, '']}
                  />
                  <Legend />
                  <Bar dataKey="Year 1" fill="#16A34A" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="Year 2" fill="#F59E0B" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="Year 3+" fill="#2563EB" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Info Text */}
            <p className="text-sm text-[#6B5A70] bg-[#F9F0F7] p-4 rounded-lg">
              If you bring <span className="font-bold text-[#702963]">{formatEur(projectedAum)}</span> in AUM
              by year-end, you'll earn{' '}
              <span className="font-bold text-[#16A34A]">{formatEur(projectedEarnings.year1)}</span> in Year 1
              commission, declining to{' '}
              <span className="font-bold text-[#2563EB]">{formatEur(projectedEarnings.year3)}</span> in Year 3+.
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  );
}

'use client';

import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import {
  TrendingUp,
  Users,
  Coins,
  Calendar,
  ArrowUpDown,
} from 'lucide-react';
import { KpiCard } from '@/components/ui/KpiCard';
import { FunnelPills } from '@/components/ui/FunnelPills';
import { AumChart } from '@/components/charts/AumChart';
import { ActivityFeed } from '@/components/dashboard/ActivityFeed';
import {
  fetchDashboardKPIs,
  fetchProfile,
  fetchClientFunnel,
  fetchTransactions,
  fetchAumHistory,
} from '@/lib/services';
import { useI18n } from '@/i18n/context';
import { DashboardKPIs, WealthManagerProfile, ClientFunnelData, Transaction, AumDataPoint } from '@/types';
import { SkeletonCard } from '@/components/ui/Skeleton';

export default function DashboardHome() {
  const { t } = useI18n();
  const [kpis, setKpis] = useState<DashboardKPIs | null>(null);
  const [profile, setProfile] = useState<WealthManagerProfile | null>(null);
  const [funnel, setFunnel] = useState<ClientFunnelData | null>(null);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [aumHistory, setAumHistory] = useState<AumDataPoint[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      try {
        const [kpisData, profileData, funnelData, transactionsData, aumData] = await Promise.all([
          fetchDashboardKPIs(),
          fetchProfile(),
          fetchClientFunnel(),
          fetchTransactions(10),
          fetchAumHistory(),
        ]);

        setKpis(kpisData);
        setProfile(profileData);
        setFunnel(funnelData);
        setTransactions(transactionsData);
        setAumHistory(aumData);
        setLoading(false);
      } catch (error) {
        console.error('Failed to load dashboard data:', error);
        setLoading(false);
      }
    };

    loadData();
  }, []);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: 'EUR',
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const formatNumber = (num: number) => {
    return new Intl.NumberFormat('fr-FR').format(num);
  };

  // Calculate next payout date
  const getNextPayoutDate = () => {
    const now = new Date();
    const currentMonth = now.getMonth();

    // Q1: Jan-Mar (payout April 1)
    // Q2: Apr-Jun (payout July 1)
    // Q3: Jul-Sep (payout Oct 1)
    // Q4: Oct-Dec (payout Jan 1)

    let nextPayoutDate: Date;
    if (currentMonth < 3) {
      nextPayoutDate = new Date(now.getFullYear(), 3, 1); // April 1
    } else if (currentMonth < 6) {
      nextPayoutDate = new Date(now.getFullYear(), 6, 1); // July 1
    } else if (currentMonth < 9) {
      nextPayoutDate = new Date(now.getFullYear(), 9, 1); // Oct 1
    } else {
      nextPayoutDate = new Date(now.getFullYear() + 1, 0, 1); // Jan 1 next year
    }

    return nextPayoutDate.toLocaleDateString('fr-FR', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.05,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 8 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.3 },
    },
  };

  return (
    <motion.div
      initial="hidden"
      animate="visible"
      variants={containerVariants}
      className="space-y-8"
    >
      {/* Welcome Section */}
      <motion.div variants={itemVariants}>
        <h1 className="text-4xl font-bold text-[#1A0918] mb-1">
          {t.overview.welcome}, {profile?.name || 'Marc'}.
        </h1>
        <p className="text-[#9B8FA0]">{t.overview.subtitle}</p>
      </motion.div>

      {/* KPI Cards */}
      <motion.div
        variants={containerVariants}
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4"
      >
        {/* Total AUM */}
        <motion.div variants={itemVariants}>
          {loading ? (
            <SkeletonCard />
          ) : (
            <KpiCard
              title={t.overview.totalAum}
              value={formatCurrency(kpis?.totalAum || 0)}
              change={kpis?.totalAumChange}
              trend="up"
              icon={<TrendingUp size={20} />}
            />
          )}
        </motion.div>

        {/* Active Clients */}
        <motion.div variants={itemVariants}>
          {loading ? (
            <SkeletonCard />
          ) : (
            <KpiCard
              title={t.overview.activeClients}
              value={`${kpis?.activeClients || 0} / ${kpis?.totalClients || 0}`}
              subtitle="of total clients"
              icon={<Users size={20} />}
            />
          )}
        </motion.div>

        {/* Est. Quarterly Commission */}
        <motion.div variants={itemVariants}>
          {loading ? (
            <SkeletonCard />
          ) : (
            <KpiCard
              title={t.overview.estimatedCommission}
              value={formatCurrency(kpis?.estimatedQuarterlyCommission || 0)}
              subtitle="Running estimate"
              icon={<Coins size={20} />}
            />
          )}
        </motion.div>

        {/* Next Payout */}
        <motion.div variants={itemVariants}>
          {loading ? (
            <SkeletonCard />
          ) : (
            <KpiCard
              title="Next Payout"
              value={getNextPayoutDate()}
              subtitle="Date countdown"
              icon={<Calendar size={20} />}
            />
          )}
        </motion.div>

        {/* Net Deposits this Quarter */}
        <motion.div variants={itemVariants}>
          {loading ? (
            <SkeletonCard />
          ) : (
            <KpiCard
              title="Net Deposits Q1"
              value={formatCurrency(
                (kpis?.totalDepositsThisMonth || 0) - (kpis?.totalWithdrawalsThisMonth || 0)
              )}
              change={
                ((kpis?.totalDepositsThisMonth || 0) - (kpis?.totalWithdrawalsThisMonth || 0)) > 0
                  ? 5.2
                  : -2.1
              }
              trend={
                ((kpis?.totalDepositsThisMonth || 0) - (kpis?.totalWithdrawalsThisMonth || 0)) > 0
                  ? 'up'
                  : 'down'
              }
              icon={<ArrowUpDown size={20} />}
            />
          )}
        </motion.div>
      </motion.div>

      {/* AUM Chart */}
      <motion.div variants={itemVariants}>
        {loading ? (
          <div className="glass-card p-8 h-96 flex items-center justify-center">
            <div className="animate-pulse text-[#9B8FA0]">{t.common.loading}</div>
          </div>
        ) : (
          <AumChart data={aumHistory} />
        )}
      </motion.div>

      {/* Two Column Section: Client Pipeline + Recent Activity */}
      <motion.div variants={itemVariants} className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Client Pipeline - Left Column */}
        <div className="glass-card p-6">
          <h3 className="text-lg font-semibold text-[#1A0918] mb-4">{t.overview.clientFunnel}</h3>
          {loading ? (
            <div className="space-y-3">
              {Array.from({ length: 3 }).map((_, i) => (
                <SkeletonCard key={i} />
              ))}
            </div>
          ) : (
            funnel && <FunnelPills data={funnel} />
          )}
        </div>

        {/* Recent Activity - Right Column (spans 2) */}
        <div className="lg:col-span-2 glass-card p-6">
          <h3 className="text-lg font-semibold text-[#1A0918] mb-4">{t.overview.recentActivity}</h3>
          <ActivityFeed transactions={transactions} loading={loading} />
        </div>
      </motion.div>
    </motion.div>
  );
}

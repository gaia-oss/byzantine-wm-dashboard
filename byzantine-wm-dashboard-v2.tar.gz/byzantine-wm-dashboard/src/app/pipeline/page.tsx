'use client';

import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useI18n } from '@/i18n/context';
import { mockClients, mockInvitations, mockProfile } from '@/lib/mock-data';
import type { Client, Invitation } from '@/types';

export default function PipelinePage() {
  const { t } = useI18n();
  const [copyFeedback, setCopyFeedback] = useState(false);

  const referralLink = `https://app.byzantine.fi/ref/${mockProfile.name.split(' ').join('-').toUpperCase()}-2025`;

  // Copy referral link
  const handleCopyLink = async () => {
    await navigator.clipboard.writeText(referralLink);
    setCopyFeedback(true);
    setTimeout(() => setCopyFeedback(false), 2000);
  };

  // Format currency
  const formatCurrency = (amount: number, currency: string = 'EUR') => {
    return new Intl.NumberFormat('de-DE', {
      style: 'currency',
      currency,
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  // Calculate days in current stage
  const getDaysInStage = (client: Client) => {
    const joinDate = new Date(client.joinDate);
    const today = new Date();
    const days = Math.floor((today.getTime() - joinDate.getTime()) / (1000 * 60 * 60 * 24));
    return days;
  };

  // Pipeline stats
  const totalInvited = mockClients.filter(c => c.status === 'invited').length;
  const totalActive = mockClients.filter(c => c.status === 'active').length;
  const conversionRate = totalInvited > 0 ? Math.round((totalActive / totalInvited) * 100) : 0;
  const totalAum = mockClients.reduce((sum, c) => sum + c.aum, 0);

  // Group clients by status
  const clientsByStatus = {
    invited: mockClients.filter(c => c.status === 'invited'),
    kyc_pending: mockClients.filter(c => c.status === 'kyc_pending'),
    kyc_approved: mockClients.filter(c => c.status === 'kyc_approved'),
    first_deposit: mockClients.filter(c => c.status === 'first_deposit'),
    active: mockClients.filter(c => c.status === 'active'),
    cancelled: mockClients.filter(c => c.status === 'cancelled'),
  };

  const kanbanColumns = [
    { status: 'invited', title: 'Invited', bgColor: 'bg-purple-50', count: clientsByStatus.invited.length },
    { status: 'kyc_pending', title: 'Signed Up', bgColor: 'bg-orange-50', count: clientsByStatus.kyc_pending.length },
    { status: 'kyc_approved', title: 'KYC Approved', bgColor: 'bg-yellow-50', count: clientsByStatus.kyc_approved.length },
    { status: 'first_deposit', title: 'First Deposit', bgColor: 'bg-blue-50', count: clientsByStatus.first_deposit.length },
    { status: 'active', title: 'Active', bgColor: 'bg-green-50', count: clientsByStatus.active.length },
  ];

  // Get badge color for invitation status
  const getInvitationBadgeClass = (status: string) => {
    switch (status) {
      case 'sent':
        return 'badge-purple';
      case 'opened':
        return 'badge-info';
      case 'registered':
        return 'badge-success';
      case 'expired':
        return 'badge-danger';
      default:
        return 'badge-purple';
    }
  };

  return (
    <div className="min-h-screen bg-surface-secondary p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-text-primary mb-2">{t.invite.title}</h1>
          <p className="text-text-secondary">{t.invite.subtitle}</p>
        </div>

        {/* A. Invite New Client Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-card p-6 space-y-6"
        >
          <div>
            <h2 className="text-xl font-semibold text-text-primary mb-4">Invite a new client</h2>
            <div className="grid grid-cols-12 gap-3 mb-4">
              <input
                type="email"
                placeholder={t.invite.emailPlaceholder}
                className="col-span-5 px-4 py-3 bg-surface border border-border rounded-lg text-text-primary placeholder-text-muted focus:outline-none focus:ring-2 focus:ring-byzantine focus:border-transparent"
              />
              <input
                type="text"
                placeholder={t.invite.namePlaceholder}
                className="col-span-4 px-4 py-3 bg-surface border border-border rounded-lg text-text-primary placeholder-text-muted focus:outline-none focus:ring-2 focus:ring-byzantine focus:border-transparent"
              />
              <button className="col-span-3 bg-byzantine hover:bg-byzantine-dark text-white font-semibold py-3 px-6 rounded-lg transition-colors">
                {t.invite.send}
              </button>
            </div>
            <textarea
              placeholder="Add a personal message (optional)"
              rows={3}
              className="w-full px-4 py-3 bg-surface border border-border rounded-lg text-text-primary placeholder-text-muted focus:outline-none focus:ring-2 focus:ring-byzantine focus:border-transparent resize-none"
            />
          </div>

          {/* Referral Link Section */}
          <div className="pt-4 border-t border-border-light">
            <p className="text-sm text-text-secondary mb-3">{t.invite.referralLink}</p>
            <div className="flex gap-3">
              <div className="flex-1 px-4 py-3 bg-surface-secondary border border-border rounded-lg text-text-primary text-sm font-mono break-all">
                {referralLink}
              </div>
              <button
                onClick={handleCopyLink}
                className={`px-6 py-3 rounded-lg font-semibold transition-all ${
                  copyFeedback
                    ? 'bg-green-500 text-white'
                    : 'bg-byzantine text-white hover:bg-byzantine-dark'
                }`}
              >
                {copyFeedback ? t.invite.copied : t.invite.copy}
              </button>
            </div>
          </div>
        </motion.div>

        {/* B. Pipeline Stats */}
        <div className="grid grid-cols-3 gap-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="glass-card p-6"
          >
            <div className="text-text-secondary text-sm mb-2">Conversion rate</div>
            <div className="text-3xl font-bold text-byzantine mb-1">{conversionRate}%</div>
            <div className="text-xs text-text-muted">Invited → Active</div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="glass-card p-6"
          >
            <div className="text-text-secondary text-sm mb-2">Avg. time to first deposit</div>
            <div className="text-3xl font-bold text-byzantine mb-1">12 days</div>
            <div className="text-xs text-text-muted">From KYC approval</div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="glass-card p-6"
          >
            <div className="text-text-secondary text-sm mb-2">Pipeline status</div>
            <div className="text-2xl font-bold text-byzantine">
              {totalActive} <span className="text-xs text-text-muted">/ {totalInvited}</span>
            </div>
            <div className="text-xs text-text-muted">Active / Invited</div>
          </motion.div>
        </div>

        {/* C. Pipeline Kanban */}
        <div className="space-y-4">
          <h2 className="text-xl font-semibold text-text-primary">Pipeline stages</h2>
          <div className="overflow-x-auto pb-4">
            <div className="flex gap-6 min-w-max">
              {kanbanColumns.map((column, columnIndex) => {
                const columnClients = clientsByStatus[column.status as keyof typeof clientsByStatus];
                return (
                  <motion.div
                    key={column.status}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.1 * columnIndex }}
                    className={`flex-shrink-0 w-80 ${column.bgColor} rounded-lg p-4`}
                  >
                    <div className="mb-4">
                      <h3 className="font-semibold text-text-primary text-sm mb-1">{column.title}</h3>
                      <div className="text-xs text-text-muted">{column.count} {column.count === 1 ? 'client' : 'clients'}</div>
                    </div>
                    <div className="space-y-3">
                      {columnClients.map((client, cardIndex) => (
                        <motion.div
                          key={client.id}
                          initial={{ opacity: 0, scale: 0.95 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ delay: 0.05 * cardIndex }}
                          className="glass-card p-4"
                        >
                          <div className="mb-3">
                            <p className="font-medium text-text-primary text-sm">{client.name}</p>
                            <p className="text-xs text-text-muted truncate">{client.email}</p>
                          </div>

                          <div className="mb-3 space-y-1 text-xs text-text-secondary">
                            <div>Joined: {new Date(client.joinDate).toLocaleDateString()}</div>
                            <div>{getDaysInStage(client)} days in stage</div>
                            {client.aum > 0 && <div>AUM: {formatCurrency(client.aum)}</div>}
                          </div>

                          <div className="flex gap-2">
                            {column.status === 'invited' && (
                              <button className="flex-1 text-xs px-3 py-2 bg-byzantine text-white rounded hover:bg-byzantine-dark transition-colors font-medium">
                                Resend
                              </button>
                            )}
                            {(column.status === 'kyc_pending' || column.status === 'kyc_approved' || column.status === 'first_deposit') && (
                              <button className="flex-1 text-xs px-3 py-2 bg-byzantine text-white rounded hover:bg-byzantine-dark transition-colors font-medium">
                                Remind
                              </button>
                            )}
                          </div>
                        </motion.div>
                      ))}
                      {columnClients.length === 0 && (
                        <div className="text-center py-8">
                          <p className="text-xs text-text-muted">No clients</p>
                        </div>
                      )}
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>

          {/* Cancelled section */}
          {clientsByStatus.cancelled.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-red-50 rounded-lg p-4"
            >
              <div className="mb-4">
                <h3 className="font-semibold text-red-900 text-sm">Cancelled ({clientsByStatus.cancelled.length})</h3>
              </div>
              <div className="space-y-2">
                {clientsByStatus.cancelled.map(client => (
                  <div key={client.id} className="glass-card p-3">
                    <p className="font-medium text-text-primary text-sm">{client.name}</p>
                    <p className="text-xs text-text-muted">{client.email}</p>
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </div>

        {/* D. Pending Invitations Table */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="glass-card overflow-hidden"
        >
          <div className="p-6 border-b border-border-light">
            <h2 className="text-lg font-semibold text-text-primary">{t.invite.pendingInvites}</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full data-table">
              <thead>
                <tr>
                  <th>{t.invite.emailPlaceholder}</th>
                  <th>{t.common.noData === t.common.noData ? 'Name' : 'Name'}</th>
                  <th>{t.invite.sentDate}</th>
                  <th>{t.invite.inviteStatus}</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {mockInvitations.map((invitation: Invitation) => (
                  <tr key={invitation.id}>
                    <td>{invitation.email}</td>
                    <td>{invitation.name}</td>
                    <td>{new Date(invitation.sentDate).toLocaleDateString()}</td>
                    <td>
                      <span className={`badge ${getInvitationBadgeClass(invitation.status)}`}>
                        {invitation.status === 'sent' && t.invite.sent}
                        {invitation.status === 'opened' && t.invite.opened}
                        {invitation.status === 'registered' && t.invite.registered}
                        {invitation.status === 'expired' && t.invite.expired}
                      </span>
                    </td>
                    <td>
                      {invitation.status === 'sent' && (
                        <button className="text-xs px-3 py-1 bg-byzantine text-white rounded hover:bg-byzantine-dark transition-colors font-medium">
                          {t.invite.resend}
                        </button>
                      )}
                      {invitation.status === 'expired' && (
                        <button className="text-xs px-3 py-1 bg-byzantine text-white rounded hover:bg-byzantine-dark transition-colors font-medium">
                          {t.invite.resend}
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
